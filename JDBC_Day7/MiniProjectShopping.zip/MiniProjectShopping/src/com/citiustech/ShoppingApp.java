package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.citiustech.model.Product;

public class ShoppingApp {

	public static void main(String[] args) throws SQLException  {
		List<Product> list = getAllProducts();
		System.out.println(list);
		
	}
	
	public static List<Product> getAllProducts() throws SQLException{
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=preImpact14;user=sa;password=password_123");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from ProductDetails");
		List<Product> list = new ArrayList<Product>();
		while(rs.next()) {
			Product obj = new Product();
			obj.setProduct_id(rs.getInt(1));
			obj.setProduct_name(rs.getString(2));
			obj.setProduct_price(rs.getFloat(3));
			list.add(obj);
		}
		
		return list;
	}

}
