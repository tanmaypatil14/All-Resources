package com.citiustech;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CallableStatementForStoredProcedure {

	public static void main(String[] args) throws ClassNotFoundException {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				try {
					Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=preImpact14;user=sa;password=password_123");
//					CallableStatement cstmt = con.prepareCall("{call getProductWithPrice}");
					CallableStatement cstmt = con.prepareCall("{call getProductById(?)}");
					int id=3;
					cstmt.setInt(1, id);
					ResultSet rs = cstmt.executeQuery();
					while(rs.next()) {
						System.out.println(rs.getString("product_name")+"--"+rs.getFloat("product_price"));
					}
					con.close();
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
				

	}

}
