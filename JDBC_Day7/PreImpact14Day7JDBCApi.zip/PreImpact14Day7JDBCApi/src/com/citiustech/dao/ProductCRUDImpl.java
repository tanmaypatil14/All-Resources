package com.citiustech.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.citiustech.model.Product;

public class ProductCRUDImpl implements ProductCRUD {
	static Connection con=null;
	static Scanner input = new Scanner(System.in);
	@Override
	public int insertProduct() {
		int rows=0;
		try {
		con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=preImpact14;user=sa;password=password_123");
		PreparedStatement pstmt = con.prepareStatement("insert into ProductDetails values(?,?,?)");
		System.out.println("Enter the ID for Product");
		int pid=input.nextInt();
		System.out.println("Enter the Name of Product");
		String pname=input.next();
		System.out.println("Enter the Price for Product");
		float pprice=input.nextFloat();
		pstmt.setInt(1, pid);
		pstmt.setString(2, pname);
		pstmt.setFloat(3, pprice);
		int row =pstmt.executeUpdate();
		rows=1;
		
		}catch(SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return rows;
	}

	@Override
	public int updateProduct() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteProduct() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getProductById() {
		// TODO Auto-generated method stub
		return null;
	}

}
