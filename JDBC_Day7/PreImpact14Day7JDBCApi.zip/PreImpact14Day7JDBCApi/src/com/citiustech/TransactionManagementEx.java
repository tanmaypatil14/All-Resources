package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class TransactionManagementEx {
	static Scanner input = new Scanner(System.in);
	public static void main(String[] args) throws ClassNotFoundException{
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		try {
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=preImpact14;user=sa;password=password_123");
		PreparedStatement pstmt = con.prepareStatement("insert into ProductDetails values(?,?,?)");
		con.setAutoCommit(false);
		System.out.println("Enter the ID for Product");
		int pid=input.nextInt();
		System.out.println("Enter the Name of Product");
		String pname=input.next();
		System.out.println("Enter the Price for Product");
		float pprice=input.nextFloat();
		pstmt.setInt(1, pid);
		pstmt.setString(2, pname);
		pstmt.setFloat(3, pprice);
		int row =pstmt.executeUpdate();
		
		System.out.println("Are you sure? ");
		String choice=input.next();
		if(choice.equals("yes"))
		{
			con.commit();
			System.out.println("Product Added");
		}
		else {
			con.rollback();
			System.out.println("Product not Added");
		}
		pstmt.close();
		con.close();
		}catch(SQLException ex) {
			System.out.println(ex.getMessage());
			
		}
		

	}

}
