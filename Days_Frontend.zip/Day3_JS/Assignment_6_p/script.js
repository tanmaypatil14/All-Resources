 'use strict'
let count = 20;
function again(){
    document.querySelector('body').style.backgroundColor="rgb(34, 55, 154)";
    const guessNum = document.getElementsByClassName("Guess");
    guessNum.value="?";
    document.getElementById("highscore").innerHTML = localStorage.getItem("highscore");
    localStorage.clear();
    Generaterandom();
}

function checkNumber(){
    const getNo = document.getElementById("getAns").value;
    const randomNum = localStorage.getItem("randomNum");
    if(Number(getNo) === Number(randomNum)){
        document.querySelector('body').style.backgroundColor="Yellow";
        localStorage.highscore = count;
        const guessNum = document.getElementsByClassName("Guess");
        guessNum.value=localStorage.randomNum;
    }else{
        count -= 1;
        localStorage.highscore = count;
        if(Number(getNo) > Number(localStorage.randomNum)) 
        confirm("Too high!");
        else 
        confirm("Too low!");
    }
    document.getElementById("highscore").innerHTML = localStorage.getItem("highscore");

}

function Generaterandom(){
    localStorage.randomNum =Math.trunc(Math.random()*20)+1;
}