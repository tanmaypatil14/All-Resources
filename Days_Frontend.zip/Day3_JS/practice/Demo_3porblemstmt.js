const massOfMark = 78;
const heightOfMark = 1.69;
const massOfjohn = 92;
const heightOfJohn = 1.95;

const bmiOfMark = massOfMark / heightOfMark * heightOfMark;

const bmiOfJohn = massOfjohn / heightOfJohn * heightOfJohn;

const higherBmi = bmiOfMark > bmiOfJohn;

console.log(higherBmi);