// 'use strict'

// let hasLic = false;
// let hasPassedDrivingTest = true;

// if(hasPassedDrivingTest)hasLic = true;
// if(hasLic)console.log("you can drive the car");

// var text = 'outside';

function logit(){
    console.log(text);
    var text = 'inside';
};
logit();

// var ten =(

//     function(x){
// return x*x;
//     }(10));