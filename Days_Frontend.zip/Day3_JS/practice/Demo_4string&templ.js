let studentFirstName = "Tanmay";
let studentlastName = "Patil";

//This is a traditional way
// let message = "The first name of student is " + studentFirstName + " and his last name is " + studentlastName + ". " + studentFirstName + " is very clever boy";
// console.log(message);

let message2 = `The first name of student is ${studentFirstName} and his last name is ${studentlastName}. ${studentFirstName} is very clever boy`
console.log(message2);