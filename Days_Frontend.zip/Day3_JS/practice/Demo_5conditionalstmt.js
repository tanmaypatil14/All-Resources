// Conditional statement
//Problem 1: for checking Login successfully

// let username = "Tanmay";
// if(username==="Tanmay")
// alert(username + " Login successfully");

// problem 2: is person elligible for getting driving license

// if-else
// const age = 17;
// if(age >= 18){
//     console.log("You are eligible for driving license");
// } else{
//     console.log("You are not eligible for driving license")
// }

// Logical operator

let age = 18;
let expiredLic = "Yes";

if(age > 18 || expiredLic === "Yes"){
    console.log("You are eligible");
} else{
    console.log("You are not eligible");
}