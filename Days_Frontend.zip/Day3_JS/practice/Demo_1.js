alert("Welcome");
let myName = "Tanmay";
alert("Welcome "+myName)
console.log(24+34);