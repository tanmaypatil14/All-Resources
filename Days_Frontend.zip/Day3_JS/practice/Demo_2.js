// Data types in JS is not a type safe
// let studentName="Tanmay";
// console.log(studentName);

// studentName=12345;
// console.log(studentName);

// studentName=true;
// console.log(studentName);

// Data types in JS 
// 1. Nmuber
// 2. String
// 3. Boolean
// 4. Undefined

// How does we get to know which data type is..?
// let studentAge=19;
// let studentName="Tanmay";
// let isStudentIsblind=false;
// let studentParentInfo;

// console.log(typeof studentAge);
// console.log(typeof studentName);
// console.log(typeof isStudentIsblind);
// console.log(typeof studentParentInfo);


