// alert("Welcome To JS session");
// let myName="Bhushan";
// alert("Welcome "+myName);
// console.log(48+48);


//How to name variables......
//1. JS keyword can't use as variable names
// let new ="Bhushan";  

//2. Variable name should follow camelcase.
// let studentName ="Bhushan";
// console.log(studentName);

//3.avoid to use Capital case for Variable name
//let PI =3.14;

//4. Var. name shouldn't start with number
// let 1StudentName="Bhushan";

//5.Var. name shouldn't have special char.
// let studentFirstAndLastName ="Bhushan P";

//6. Var. name should  make  some sense.


//Data types in JS
// For understanding Non type safe beh.
// let studentName="John";
// console.log(studentName);

// studentName=12345;
// console.log(studentName);

// studentName=true;
// console.log(studentName);

// data types
//1. Number -It is consider a number as a float value
//2. String - sequence of characters
//3. Boolean - true or false for checking conditions
//4. undefined -

// let studentAge=18;
// let studentName="John";
// let isStudentBlind=false;
// let studentParentInfo;

// console.log(typeof studentAge);
// console.log(typeof studentName);
// console.log(typeof isStudentBlind);
// console.log(typeof studentParentInfo);

// let, var and const
// let studentName="Bhushan";
// console.log("Name of Student ="+studentName)
// let rateOfInterest;

// rateOfInterest =7;
// console.log(rateOfInterest);

// rateOfInterest=10;
// console.log(rateOfInterest);

// const valueOfPi =3.14;
// console.log(valueOfPi);

// var ageOfStudent=10;
// console.log(ageOfStudent);
// ageOfStudent=20;
// console.log(ageOfStudent);

// --------------------------------------------
//Operators
// Arithmetic
// const presentYear=2022;
// let ageOfStudent1= presentYear-1980;
// let ageOfStudent2 = presentYear-1982;

// console.log(ageOfStudent1);
// console.log(ageOfStudent2);
// // -------------------------------------------
// //Assignments Operators
// let x=10+5;
// x +=10; //x=x+10;
// x *=4;
// console.log(x);
// ------------------------------------------

//comparision opertors
// let num1=10;
// let num2=20;
// //comp. operator =>  > < >= <= !=
// console.log(num1>num2);
// ---------------------------------------------


//problem statement in ppt
// Calculate BMI
// 3**2 = 9
// 2**3 = 8
//BMI = mass/ height **2;  // ** is use to calculate exponent
// BMI = mass / height * height
// const massOfMark= 78;
// const heightOfMark = 1.69;
// const massOfJohn = 92;
// const heightOfJohn =1.85;

// const bmiOfMark = massOfMark / heightOfMark*heightOfMark;
// const bmiOfJohn = massOfJohn / heightOfJohn*heightOfJohn;

// const heigherBmi = bmiOfMark>bmiOfJohn;
// console.log(heigherBmi);

//-------------String and String Templates
// let studentFirstName= "John";
// let studentLastName= "Conor";

// let studentFullName= studentFirstName+" "+studentLastName;
// console.log(studentFullName);
// console.log(studentFirstName+" "+studentLastName);
// // The first Name of Student is John and his last Name is Conor. John
// //is very clever boy. 
// let message = "The First Name of student"+studentFirstName+" and his last  name is "+studentLastName+"."+studentFirstName+" is very clever Boy.";
// console.log(message);

// let message2 = `The First Name of student is ${studentFirstName} and his last name is ${studentLastName}. ${studentFirstName} is very clever Boy..`;
// console.log(message2);

// Conditional statements
// for checking login
// let username="Bhushan1";
// if(username==="Bhushan")
// alert(username +" Login Successfully");


// Scenarion is person eligible for gettting driv. lic.
// ---if
// if age > 18 
//---- if -- else
// const age = 19;
// if(age>=18){
//      console.log("You are Eligible for Getting Driv. Lic");
// }
// else{
//     console.log("You are not eligible");
// }

// else if
//scenario is if age = 18 -> "Wait for three months", if age<18 -> "You are not elgible"
//if age > 18 then you are eligible
// const age=18;
// if(age>18){
//     console.log("You are Eligible for Getting Driv. Lic");
// }
// else if(age==18){
//     console.log("Wait for three months");
// }
// else{
//     console.log("You are not eligible");
// }

//-------------------Conversion and coersion
// type conversion
// let ageOfStudent ="38";
// console.log(ageOfStudent+10);
// console.log(typeof ageOfStudent);
// console.log(Number(ageOfStudent)+10);

// let myVariable = "hello";
// console.log(Number(myVariable));

// let percentage =75;
// console.log(typeof percentage);
// console.log(String(percentage));

// //coercion
// console.log("I am Jonh and my Age is "+18);
// console.log("20"+"20");


// console.log("25"-"20");
// console.log("25"*"20");
// console.log("25"/"20");


//------------------- == vs ===
// let age ="18";
// if(age===18)alert("Age is "+age);

// ------------------Logical operators
// let age=19;
// let expiredLic ="No";
// if(age>18 || expiredLic==="Yes"){
//     console.log("You are ready to go.........");
// }
// else{
//     console.log("Stop")
// }
// ------------------------
// switch case:

// let myChoice = 'mobile';
// switch (myChoice) {
//     case 'laptop':
//         console.log("You have selected Laptop Cat.");
//         break;
//     case 'mobile':
//         console.log("You have selected Mob. cat.");
//         break;
//     case 'fashion':
//         console.log("You have selected Fashion cat.");
//         break;
//     default:
//         console.log("Wrong Choice..");

// }

//------------------ternary operator
// let age=19;
// age>18?console.log("Eligible"):console.log("Not Eligible");

//-------------------------Looping constructs

let employee = ['John','James','Jason','Kevin','Tom','Timo'];
                // 0    1           2   3       4   5
        // console.log(employee[1]);
        // console.log(employee);
//------------for loop
for(let i=0;i<employee.length;i++){
    console.log(employee[i]);
}

// ------------for in 
for(let emp in employee){
    console.log("Name of Employee ="+employee[emp]);
}

//-------------while
let j=0;
while(j<employee.length){
    console.log("Name of Employee ="+employee[j]);
    j++;
}

//--------------Do while loop
let k=0;
do{
    console.log("Name of Employee ="+employee[k]);
    k++;
}while(k<employee.length);

















