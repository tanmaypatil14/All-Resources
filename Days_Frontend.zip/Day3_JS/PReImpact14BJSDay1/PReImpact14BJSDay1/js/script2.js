
// alert("Hi");
// let myVar=10;
//------------------Strict modde..
// 'use strict'
// let hasLic = false;
// let hasPassedDrivingTest = true;
// if(hasPassedDrivingTest)hasLic =true;
// if(hasLic)console.log("You can drive the car");


//---------------------Functions

//this is a simple function without parameter.
// function greetMorningWishes(){
// console.log("Good Mornin");
// console.log("I hope you had breakfast");
// console.log("It's sunny day");
// console.log("Have good day");
// }

// //function with parameters
// function makingJuiceFromFruits(apples, oranges){
//     let cutPiecesOfApples = cutFruitsInPieces(apples);
//     let cutPiecesOfOranges = cutFruitsInPieces(oranges);
//     let message =`Juice is ready with  ${cutPiecesOfApples} pieces of apples and ${cutPiecesOfOranges} pieces of oranges`;
//     // console.log(`Juice is ready with ${apples} apples and ${oranges} oranges`);
//     return message;
// }

// console.log(cutFruitsInPieces(2));


// function cutFruitsInPieces(fruit){

//     return fruit*4;
// }



// console.log(makingJuiceFromFruits(4,6));

// function as an expression
// Annonymous function
 const studentInfo = function (studentName){
     return `Student's Full name =${studentName}`;
 }
 
//  const result= studentInfo('Zanillia');
//  console.log(result);



//Arrow Function
//arrao function in a single line
// const carInfo = (carName,caPrice) =>  `Car Name =${carName} and Price =${caPrice}`;

// const cinfo= carInfo("Harrier", 17);
// console.log(cinfo);

// // arrow function with multiple lines with muliple parameters
// const yearLeftForRetirement = (yearOfBirth, nameOfEmployee)=>{
//     const currentAge = 2022 - yearOfBirth;
//     const yearLeft = 58-currentAge;
//     let message=`${nameOfEmployee} will be retired in ${yearLeft} years`;
//     return message;
// }
// console.log(yearLeftForRetirement(1990,"John"));











// greetMorningWishes();


// greetMorningWishes();