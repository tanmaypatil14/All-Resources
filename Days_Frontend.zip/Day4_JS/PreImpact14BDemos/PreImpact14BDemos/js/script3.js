// let username="Bhushan";
// let password="Bhushan";

// if(username==="Bhushan"&&password==="Bhushan")
// alert("Login done.......");

//storing values in format of key value
localStorage.setItem("username","Bhushan");

// localStorage.setItem("password","Bhushan");
localStorage.password="Bhushan";

// document.querySelector("#myp1").innerHTML="Welcome "+localStorage.username;
document.querySelector("#myp1").innerHTML="Welcome "+localStorage.getItem("username");

document.querySelector('#submit').addEventListener('click',function(){
    // alert("It's wokring");
    if(document.querySelector('#username').value===localStorage.username &&
    document.querySelector("#password").value===localStorage.password){
        alert("You are valid user.....")
    }
    else{
        alert("You are not valid user...")
    }

    // localStorage.removeItem("username");
})

