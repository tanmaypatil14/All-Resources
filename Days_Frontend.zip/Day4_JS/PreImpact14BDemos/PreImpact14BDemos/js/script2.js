console.log(document.querySelector('#ih2').innerHTML);
console.log(document.querySelector('#ih2').textContent);

console.log(document.getElementById('ih2').innerHTML);

console.log(document.querySelector('.mh1').innerHTML);

// here I have used querySelectorAll method to get all elements with class
// selector .mh1
const mh1 = document.querySelectorAll('.mh1');
console.log(mh1[0].innerHTML);
console.log(mh1[1].textContent);

console.log(document.getElementsByClassName('mh1'));
let mh1Elements = document.getElementsByClassName('mh1');
console.log(mh1Elements[0].innerHTML);
console.log(mh1Elements[1].innerHTML);
console.log(mh1Elements[2].innerHTML);

// document.querySelector('.mh1').innerHTML="John";
// document.querySelector('#ih2').innerHTML="James"
// mh1Elements[1].innerHTML="Changed";


//creating events on button
document.querySelector(".myButton").addEventListener('click', function () {
    // alert("Button Clicked");
    console.log(document.querySelector('.age').value);
    document.querySelector('.nage').innerHTML = document.querySelector('.age').value;

});

document.querySelector(".myButton2").addEventListener('click', function () {
    document.querySelector('body').style.backgroundColor="green";
    document.querySelector('.mh1').innerHTML = "John";
    document.querySelector('#ih2').innerHTML = "James"
    mh1Elements[1].innerHTML = "Changed";
    document.querySelector('.mh1').style.color="White";
    document.querySelector('#ih2').style.color="White";

})





