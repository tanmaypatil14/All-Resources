// //--------------------Arrays
// //way 1
// const studentsName= ['James','John','Kevin'];
// //                      0       1      2
// console.log(studentsName);

// //way 2
// const employee = new Array('James','John','Kevin');
// console.log(employee);


// console.log(employee[0]);

// console.log("Length ="+employee.length)

// employee[0]="Simon";

// console.log(employee);
// employee[3]="Sim";
// employee[4]='Kim';
// employee[5]="Tom";
// employee[6]='Kevin';
// console.log(employee);


// //----------Methods of Array
// //push
// employee.push("Jason");
// console.log(employee);

// //unshift
// employee.unshift("Zanillia");
// console.log(employee);

// //pop
// employee.pop();
// console.log(employee);

// //shift
// employee.shift();
// console.log(employee);

// //indexOf
// console.log(employee.indexOf('Kim'));

// console.log(employee.includes("Kim"));
// //-----------------------------------------------
// const firstName="Bhushan";
// const bhushanDetails = [firstName,'Kumar',employee, 2022-1980];
// console.log(bhushanDetails);


//Implement for loop - try by yourself



//Objects
// //creating object for Car -- Tata NExon
// const tataNexon=
// {
//     //key           value
//     chesisNumber:123455678,
//     carColor:'Red',
//     carPrice:13,
//     carFeature:'EV',
//     yearOFMan:2022,
//     ageOfCar:15
// }


// console.log(tataNexon);
// //--------------done using . 
// console.log('Chesis Number '+tataNexon.chesisNumber);
// console.log('Color ='+tataNexon.carColor);
// tataNexon.carColor='Black';
// console.log('Color ='+tataNexon.carColor);
// tataNexon.carPrice=14;
// console.log(tataNexon.carPrice);


// //------------------done with []
// console.log("using []")
// console.log('Chesis Number '+tataNexon['chesisNumber']);
// console.log("Color ="+tataNexon['carColor']);


// tataNexon.man ="Tata";
// console.log(tataNexon);

// tataNexon['carSegment']='Compact SUV'
// console.log(tataNexon);









