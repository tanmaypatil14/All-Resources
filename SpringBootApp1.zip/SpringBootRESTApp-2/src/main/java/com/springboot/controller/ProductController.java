package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.dao.ProductDao;
import com.springboot.model.Product;

@RestController
@RequestMapping(value = "/api")
public class ProductController {

	@Autowired
	private ProductDao productDao;

//	@RequestMapping(value="productDetails", method = RequestMethod.GET)
	@GetMapping("/productDetails")
	public List<Product> getProductDetails() {
		return productDao.getAllDetails();
	}

//	@RequestMapping(value="addProduct", method = RequestMethod.POST)
	@PostMapping("/addProduct")
	public String addProductDetails() {
		Product p = new Product(104, "Chair", 399.9);
		productDao.addProducts(p);
		return "Inserted";
	}

	@GetMapping("/productDetails/{id}")
	public Product getProductByIdDetails(@PathVariable("id") int id) throws Exception {
		return productDao.getProductById(id);
	}

	@PutMapping("/productDetails/{id}")
	public String updateProductDetails(@PathVariable("id") int id) throws Exception {
		productDao.updateProduct(id);
		return "Updated";
	}
	
	@DeleteMapping("/productDetails/{id}")
	public String deleteProductDetails(@PathVariable("id") int id) throws Exception {
		productDao.deleteProduct(id);
		return "Deleted";
	}
}
