package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApp2Application.class, args);
	}

}
