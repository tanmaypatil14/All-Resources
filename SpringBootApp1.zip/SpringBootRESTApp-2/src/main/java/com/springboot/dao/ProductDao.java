package com.springboot.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springboot.model.Product;

@Repository
public class ProductDao {

	static List<Product> pList = new ArrayList<Product>();
	
	static {
		pList.add(new Product(101, "Bag", 89.90));
		pList.add(new Product(102, "Box", 99.90));
		pList.add(new Product(103, "Table", 189.90));
	}

	private Product product;
	
	public List<Product> getAllDetails() {
		
		return pList;
	}
	
	public void addProducts(Product p) {
		pList.add(p);
	}
	
	public Product getProductById(int id) {
		for (Product product : pList) {
			if(product.getId()==id) {

				return product;
			} 
		}
		return product;
	}
	
	public void updateProduct(int id) {
		for (Product product : pList) {
			if(product.getId()==id) {
				product.setName("Bascket");
				product.setPrice(299.90);
				System.out.println("Product Updated");
			} else {
				System.out.println("Id not found");
			}
		}
	}
	
	@SuppressWarnings("unused")
	public void deleteProduct(int id) {
		
	for(Product product1 : pList)
		if(product1.getId() == id) {
			if(product1 == null) {
				System.out.println("Invalid Id");
			} else {
				pList.remove(product1);
			}
		}
	}
}
