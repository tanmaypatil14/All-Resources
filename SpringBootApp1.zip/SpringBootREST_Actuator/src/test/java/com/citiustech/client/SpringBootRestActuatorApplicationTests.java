package com.citiustech.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestActuatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
