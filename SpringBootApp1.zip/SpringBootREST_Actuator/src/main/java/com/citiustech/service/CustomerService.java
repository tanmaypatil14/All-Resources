package com.citiustech.service;

import java.util.List;

import com.citiustech.dto.CustomerDTO;
import com.citiustech.exception.CustomerException;

public interface CustomerService {

	public Integer addCustomer(CustomerDTO customerDTO) throws CustomerException;

	public CustomerDTO getCustomer(Integer customerId) throws CustomerException;

	public void updateCustomer(Integer customerId, CustomerDTO customerDTO) throws CustomerException;

	public void deleteCustomer(Integer customerId) throws CustomerException;

	public List<CustomerDTO> getAllCustomers() throws CustomerException;

}
