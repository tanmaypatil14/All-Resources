package com.citiustech.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.citiustech.dto.CustomerDTO;
import com.citiustech.entity.Customer;
import com.citiustech.exception.CustomerException;
import com.citiustech.repository.CustomerRepository;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	public Integer addCustomer(CustomerDTO customerDTO) throws CustomerException {
		Customer customerEntity = new Customer();
		customerEntity.setCustomerId(customerDTO.getCustomerId());
		customerEntity.setEmailId(customerDTO.getEmailId());
		customerEntity.setName(customerDTO.getName());
		customerEntity.setDateOfBirth(customerDTO.getDateOfBirth());
		
		Customer customerEntity2 = customerRepository.save(customerEntity);
		return customerEntity2.getCustomerId();
	}

	@Override
	public CustomerDTO getCustomer(Integer customerId) throws CustomerException {
		Optional<Customer> optional = customerRepository.findById(customerId);
		Customer customer = optional.orElseThrow(() -> new CustomerException("Service.CUSTOMER_NOT_FOUND"));
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerId(customer.getCustomerId());
		customerDTO.setEmailId(customer.getEmailId());
		customerDTO.setName(customer.getName());
		customerDTO.setDateOfBirth(customer.getDateOfBirth());
				
		return customerDTO;
	}

	@Override
	public void updateCustomer(Integer customerId, CustomerDTO customerDTO) throws CustomerException {
		Optional<Customer> optional = customerRepository.findById(customerId);
		Customer customer = optional.orElseThrow(() -> new CustomerException("Service.CUSTOMER_NOT_FOUND"));
		customer.setEmailId(customerDTO.getEmailId());
		customer.setName(customerDTO.getName());
		customer.setDateOfBirth(customerDTO.getDateOfBirth());
	}

	@Override
	public void deleteCustomer(Integer customerId) throws CustomerException {
		Optional<Customer> optional = customerRepository.findById(customerId);
		optional.orElseThrow(() -> new CustomerException("Service.CUSTOMER_NOT_FOUND"));
		customerRepository.deleteById(customerId);
	}

	@Override
	public List<CustomerDTO> getAllCustomers() throws CustomerException {
		Iterable<Customer> iterable = customerRepository.findAll();
		
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		
		iterable.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTOs.add(customerDTO);
		});
		
		if(customerDTOs.isEmpty())
			throw new CustomerException("Service.CUSTOMERS_NOT_FOUND");
		return customerDTOs;
	}

}
