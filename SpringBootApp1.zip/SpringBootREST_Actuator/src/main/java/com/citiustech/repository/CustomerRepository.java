package com.citiustech.repository;

import org.springframework.data.repository.CrudRepository;

import com.citiustech.entity.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Integer> {

}
