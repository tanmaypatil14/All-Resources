package com.citiustech.utility;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.citiustech.exception.CustomerException;

@RestControllerAdvice
public class ExceptionControllerAdvice {

	@Autowired
	private Environment environment;

	private ErrorInfo error = new ErrorInfo();

//	Here is the @ExceptionHandler annotation so that we need to specify the exception name
//	Whenever throught this project wherever any exception is thrown this is handle
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorInfo> exceptionHandler(Exception exception) {

		error.setErrorMessage(environment.getProperty("General.EXCEPTION_MESSAGE"));
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		error.setTimestamp(LocalDateTime.now());
		return new ResponseEntity<ErrorInfo>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

//	Whenever we want throw a specific exception we need to throw the our customize exception
	@ExceptionHandler(CustomerException.class)
	public ResponseEntity<ErrorInfo> customerExceptionHandler(CustomerException customerException) {

		error.setErrorMessage(environment.getProperty(customerException.getMessage()));
		error.setErrorCode(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());

		return new ResponseEntity<ErrorInfo>(error, HttpStatus.NOT_FOUND);
	}
}
