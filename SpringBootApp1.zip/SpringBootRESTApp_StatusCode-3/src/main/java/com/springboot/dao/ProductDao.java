package com.springboot.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springboot.model.Product;

@Repository
public class ProductDao {

	static List<Product> pList = new ArrayList<Product>();

	static {
		pList.add(new Product(101, "Bag", 1992.90));
		pList.add(new Product(102, "Pencil", 19.90));
		pList.add(new Product(103, "Chair", 1999.90));
		pList.add(new Product(104, "Helmet", 5999.90));
	}

	public List<Product> getAllProduct() {
		return pList;
	}
	
	public Product getProductById(int id) {
		Product product = new Product();
		for(Product p : pList) {
			if(p.getId()==id) {
				return p;
			}
		}
		return product;
	}
	
	public void addProduct(Product p1) {
		pList.add(p1);
	}
	
	public void updateProduct(int id) {
		for(Product p : pList) {
			if(p.getId()==id) {
				p.setName("Keybord");
				p.setPrice(1599.9);
				System.out.println("Updated");
			} else {
				System.out.println("Id not found");
			}
		}
	}
	
	public void deleteProduct(int id) {
		for(Product p : pList) {
			if(p.getId()==id) {
				pList.remove(p);
				System.out.println("Deleted");
			} else {
				System.out.println("Id not found");
			}
		}
	}
}
