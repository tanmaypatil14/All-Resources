package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.dao.ProductDao;
import com.springboot.model.Product;

@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	private ProductDao productDao;

	@GetMapping("/product")
	public ResponseEntity<List<Product>> getProductDetails() {
		if (productDao.getAllProduct().isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity(productDao.getAllProduct(), HttpStatus.OK);
		}
	}

	@GetMapping("/product/{id}")
	public ResponseEntity<Product> getProductByIdDetails(@PathVariable("id") int id) {
		return new ResponseEntity(productDao.getProductById(id), HttpStatus.OK);
	}

	@PostMapping("/product")
	public ResponseEntity<String> addProductDetails() {
		Product product = new Product(105, "Table", 4999.99);
		productDao.addProduct(product);
		return new ResponseEntity("INSERTED", HttpStatus.ACCEPTED);
	}
	
	@PutMapping("/product/{id}")
	public ResponseEntity<String> updateProductDetails(@PathVariable ("id") int id) {
		productDao.updateProduct(id);
		return new ResponseEntity ("UPDATED",HttpStatus.OK);
	}
	
	@DeleteMapping("/product/{id}")
	public ResponseEntity<String> deleteProductDetails(@PathVariable ("id") int id) {
		productDao.deleteProduct(id);
		return new ResponseEntity ("DELETED",HttpStatus.OK);
	}
}
