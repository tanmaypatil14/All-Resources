package com.springboot.controller;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api")
public class ProductController {
	
	private static Logger logger = Logger.getLogger(ProductController.class);
	
	@RequestMapping(value="/product", method=RequestMethod.GET)
	public String getProductDetails() {
		
		logger.info("This is info level message");
		return "Product details are here";
	}
	
	@RequestMapping(value="/productwithcode", method=RequestMethod.GET)
	public String getProductDetailsWithCode() {
		return "Product details are here with code 101";
	}
	
	@RequestMapping(value="/productadd", method=RequestMethod.POST)
	public String addProductDetails() {
		return "Add";
	}
	
	@RequestMapping(value="/productupdate", method=RequestMethod.PUT)
	public String updateProductDetails() {
		return "Update";
	}
	
	@RequestMapping(value="/productdelete", method=RequestMethod.DELETE)
	public String deleteProductDetails() {
		return "Delete";
	}
}
