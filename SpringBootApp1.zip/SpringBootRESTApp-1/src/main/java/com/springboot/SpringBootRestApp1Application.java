package com.springboot;

import java.io.File;

import org.apache.log4j.PropertyConfigurator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApp1Application.class, args);
		
		PropertyConfigurator.configure(System.getProperty("user.dir") + File.separator + "log4j.properties");
//		PropertyConfigurator.configure(System.getProperty("user.dir") + File.separator + "SpringBootRESTApp-1\src/main/resources/log4j.properties");
	}

}
