package com.springprofile;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class SpringBootProfileApplication {

	public static void main(String[] args) {
		new SpringApplicationBuilder(SpringBootProfileApplication.class).profiles("dev", "prod", "qa").run(args);
	}

}

@Component
class MyRunner implements CommandLineRunner {
	@Autowired
	private Environment environment;

	@Override
	public void run(String... args) throws Exception {
//		System.out.println("Active Profiles: " + Arrays.toString(environment.getActiveProfiles()));

	}
}

@Component
@Profile("dev")
class MuRunner2 implements CommandLineRunner {

	@Override
	public void run(String... args) throws Exception {
//		System.out.println("In developement");

	}

}

@Component
@Profile("prod")
class MuRunner3 implements CommandLineRunner {

	@Override
	public void run(String... args) throws Exception {
//		System.out.println("In Production");

	}

}

@Component
@Profile("qa")
class MuRunner4 implements CommandLineRunner {

	@Override
	public void run(String... args) throws Exception {
		System.out.println("In Q and Testing");

	}

}
