package com.citiustech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class SpringBootRestAppExceptionHandling4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestAppExceptionHandling4Application.class, args);
	}

}
