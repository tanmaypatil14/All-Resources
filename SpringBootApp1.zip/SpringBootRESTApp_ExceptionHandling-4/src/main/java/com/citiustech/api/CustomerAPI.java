package com.citiustech.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.dto.CustomerDTO;
import com.citiustech.exception.CustomerException;
import com.citiustech.service.CustomerService;

@RestController
@RequestMapping("/ct/v1")
public class CustomerAPI {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private Environment environment;

	@GetMapping("/customers")
	public ResponseEntity<List<CustomerDTO>> getAllCustomers() throws CustomerException {
		List<CustomerDTO> customerDTOList = customerService.getAllCustomers();
		return new ResponseEntity<>(customerDTOList, HttpStatus.OK);
	}

	@GetMapping("/customers/{customerId}")
	public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable("customerId") Integer customerId)
			throws CustomerException {
		CustomerDTO customerDTO = customerService.getCustomer(customerId);
		return new ResponseEntity<>(customerDTO, HttpStatus.OK);
	}

	@PostMapping("/customers")
	public ResponseEntity<String> addCustomerData(@RequestBody CustomerDTO customerDTO) throws CustomerException {
		Integer customerId = customerService.addCustomer(customerDTO);
		String successMessage = environment.getProperty("API.INSERT_SUCCESS") + customerId;
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}

	@PutMapping("/customers/{customerId}")
	public ResponseEntity<String> updateCustomerData(@PathVariable("customerId") Integer customerId,
			@RequestBody CustomerDTO customerDTO) throws CustomerException {
		customerService.updateCustomer(customerId, customerDTO);
		String successMessage = environment.getProperty("API.UPDATE_SUCCESS");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

	@DeleteMapping("/customers/{customerId}")
	public ResponseEntity<String> deleteCustomerData(@PathVariable("customerId") Integer customerId)
			throws CustomerException {
		customerService.deleteCustomer(customerId);
		String successMessage = environment.getProperty("API.DELETE_SUCCESS");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}
}
